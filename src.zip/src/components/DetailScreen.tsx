import React, {useEffect, useRef} from 'react';
import {Animated, SafeAreaView, Text, View} from 'react-native';
import LottieView from 'lottie-react-native';

const DetailScreen = () => {
  const progress = useRef(new Animated.Value(0)).current;

  // useEffect(() => {
  //   handleLikeAnimation();
  // }, []);

  const handleLikeAnimation = () => {
    Animated.timing(progress, {
      toValue: 1,
      duration: 10000,
      useNativeDriver: true,
    }).start();
  };

  return (
    <SafeAreaView>
      <Text>Lottie View Animation</Text>
      <View style={{height: 400, width: 400}}>
        <LottieView
          // progress={progress}
          source={require('../assets/error.json')}
          autoPlay loop 
        />
      </View>
    </SafeAreaView>
  );
};

export default DetailScreen;
