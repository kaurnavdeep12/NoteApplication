export type AuthParamList = {
    UserList: undefined,
    DetailScreen:undefined
}